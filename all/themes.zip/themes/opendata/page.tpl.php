	<!-- Page Wrapper -->
	    <div id="page-wrapper">

		<!-- Header -->

		<!-- Banner -->
		    <section id="banner">
			<div class="inner">
			    <div class="logo"><img src="<?php echo $directory ?>/images/miskolc_opendata_logo.png"></div>
			    <h2>Free quality data access!</h2>
			    <p>Made by Mskolcholding IT Group</a></p>
			</div>
		    </section>

		<!-- Wrapper -->
		    <section id="wrapper">

			<!-- One -->
			    <section id="one" class="wrapper spotlight style1">
				<div class="inner">
				    <a href="#" class="image"><img src="<?php echo $directory ?>/images/pic01.jpg" alt="" /></a>
				    <div class="content">
					<h2 class="major">About Miskolc Smart City</h2>
					<p>Miskolc is near to Bükk Hills lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
					<a href="#" class="special">Learn more</a>
				    </div>
				    
				</div>
				<div class="inner">
				    <a href="#" class="image"><img src="<?php echo $directory ?>/images/pic02.jpg" alt="" /></a>
				    <div class="content">
					<h2 class="major">Tempus adipiscing</h2>
					<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
					<a href="#" class="special">Learn more</a>
				    </div>
				</div>
				<div class="inner">
				    <a href="#" class="image"><img src="<?php echo $directory ?>/images/pic03.jpg" alt="" /></a>
				    <div class="content">
					<h2 class="major">Nullam dignissim</h2>
					<p>Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.</p>
					<a href="#" class="special">Learn more</a>
				    </div>
				</div>
			    </section>

			

			<!-- Four -->
			    <section id="four" class="wrapper alt style1">
				<div class="inner">
				    <h2 class="major">Downloadable Contents</h2>
				    <p>Cras mattis ante fermentum, malesuada neque vitae, eleifend erat. Phasellus non pulvinar erat. Fusce tincidunt, nisl eget mattis egestas, purus ipsum consequat orci, sit amet lobortis lorem lacus in tellus. Sed ac elementum arcu. Quisque placerat auctor laoreet.</p>
				    <section class="features">
					<article>
					    <a href="#" class="image"><img src="<?php echo $directory ?>/images/pic04.jpg" alt="" /></a>
					    <h3 class="major">PROGRAMS</h3>
					    <p><a href="/sites/default/files/opendata/programok_xml.zip">XML</a></p>
					    <a href="#" class="special">Learn more</a>
					</article>
					<article>
					    <a href="#" class="image"><img src="<?php echo $directory ?>/images/pic05.jpg" alt="" /></a>
					    <h3 class="major">SHOPS</h3>
					    <p><a href="/sites/default/files/opendata/shops_pdf.zip">PDF</a>, <a href="/sites/default/files/opendata/shops_sql.zip">SQL</a>, <a href="/sites/default/files/opendata/shops_json.zip">JSON</a>, <a href="/sites/default/files/opendata/shops_xml.zip">XML</a></p>
					    <a href="#" class="special">Learn more</a>
					</article>
					<article>
					    <a href="#" class="image"><img src="<?php echo $directory ?>/images/pic06.jpg" alt="" /></a>
					    <h3 class="major">STATUES</h3>
					    <p><a href="/sites/default/files/opendata/statues_pdf.zip">PDF</a>, <a href="/sites/default/files/opendata/statues_sql2.zip">SQL</a>, <a href="/sites/default/files/opendata/statues_json.zip">JSON</a>, <a href="/sites/default/files/opendata/statues_xml.zip">XML</a></p>
					    <a href="#" class="special">Learn more</a>
					</article>
					<article>
					    <a href="#" class="image"><img src="<?php echo $directory ?>/images/pic07.jpg" alt="" /></a>
					    <h3 class="major">MORE CONTENT...</h3>
					    <p>Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.</p>
					    <a href="#" class="special">Learn more</a>
					</article>
				    </section>
				    <ul class="actions">
					<li><a href="#" class="button">Browse All</a></li>
				    </ul>
				</div>
			    </section>

		    </section>

		<!-- Footer -->
		    <section id="footer">
			<div class="inner">
			    <h2 class="major">Get in touch</h2>
			    <p>Cras mattis ante fermentum, malesuada neque vitae, eleifend erat. Phasellus non pulvinar erat. Fusce tincidunt, nisl eget mattis egestas, purus ipsum consequat orci, sit amet lobortis lorem lacus in tellus. Sed ac elementum arcu. Quisque placerat auctor laoreet.</p>
			    <ul class="copyright">
				<li>&copy; 2016</li><li>Információ: <a href="http://miskolcholding.hu">miskolcholding</a></li>
			    </ul>
			</div>
		    </section>

	    </div>